// This component has been replaced by TopBar.tsx and AppSidebar.tsx
// Keeping this file to avoid breaking any potential imports
export {};
