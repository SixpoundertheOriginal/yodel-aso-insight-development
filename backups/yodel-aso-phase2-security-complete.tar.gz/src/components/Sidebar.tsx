
// This file has been replaced by AppSidebar.tsx
// The old Sidebar component is no longer used
export {};
