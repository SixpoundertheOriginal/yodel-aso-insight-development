import { useState, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { isAIInsightsEnabled } from '@/constants/features';
import type { MetricsData, FilterContext, EnhancedAsoInsight } from '@/types/aso';
export type { EnhancedAsoInsight } from '@/types/aso';

export const useEnhancedAsoInsights = (
  organizationId: string | null,
  metricsData: MetricsData | undefined = undefined,
  filterContext: FilterContext | undefined = undefined,
  options: { isSuperAdmin?: boolean; enabled?: boolean } = {}
) => {
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  const { isSuperAdmin = false, enabled = false } = options;
  
  // Global kill-switch: hard no-op when AI insights disabled (unless super admin)
  const isEnabled = !!enabled && isAIInsightsEnabled(isSuperAdmin);

  // Handle missing organization context gracefully
  const hasValidOrganization = !!(organizationId && organizationId.trim());
  
  // Regular users MUST have organization (maintain security)
  // Super admins can operate without organization for platform-wide view
  const shouldReturnEmpty = !isSuperAdmin && !hasValidOrganization;

  // Fetch existing insights from database - always call this hook
  const {
    data: existingInsights = [],
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ['enhanced-aso-insights', organizationId],
    queryFn: async () => {
      if (!organizationId) return [];
      
      const { data, error } = await supabase
        .from('apps' as any) // ai_insights table doesn't exist, using apps as fallback
        .select('*')
        .eq('organization_id', organizationId)
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;

      return (data || []).map((insight: any) => ({
        id: insight.id,
        title: insight.app_name || 'Insight',
        description: insight.app_description || '',
        type: 'keyword_optimization' as const,
        priority: 'medium' as const,
        confidence: 0,
        actionable_recommendations: [],
        metrics_impact: {
          impressions: 'See detailed analysis',
          downloads: 'See detailed analysis',
          conversion_rate: 'See detailed analysis'
        },
        related_kpis: [],
        is_user_requested: false,
        created_at: insight.created_at
      })) as unknown as EnhancedAsoInsight[];
    },
    enabled: isEnabled && hasValidOrganization,
    staleTime: 5 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
    retry: 2,
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000)
  });
  // Generate AI insights for specific analysis type
  const generateInsight = useCallback(async (
    insightType: string,
    userRequested: boolean = true
  ): Promise<EnhancedAsoInsight[]> => {
    // If feature disabled, do nothing
    if (!isEnabled) {
      return [];
    }

    // Super admin without organization - return empty
    if (isSuperAdmin && !organizationId) {
      return [];
    }
    
    if (!metricsData || !organizationId) {
      throw new Error('Missing metrics data or organization ID');
    }

    setIsGenerating(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('ai-insights-generator', {
        body: {
          metricsData,
          organizationId,
          insightType,
          userRequested,
          filterContext
        }
      });

      if (error) throw error;

      const insights = data.insights || [];
      
      // Refetch to get updated list
      await refetch();
      
      return insights;
    } catch (error) {
      console.debug('Error generating insights:', error);
      if (isAIInsightsEnabled(isSuperAdmin)) {
        toast({
          title: "Insight Generation Failed",
          description: "Unable to generate insights. Please try again.",
          variant: "destructive"
        });
      }
      // Return empty array instead of throwing
      return [];
    } finally {
      setIsGenerating(false);
    }
  }, [
    metricsData, 
    organizationId, 
    filterContext?.dateRange?.start,
    filterContext?.dateRange?.end,
    filterContext?.trafficSources,
    filterContext?.selectedApps,
    refetch, 
    toast, 
    isSuperAdmin
  ]);

  // Generate comprehensive insights automatically
  const generateComprehensiveInsights = useCallback(async () => {
    return generateInsight('comprehensive', false);
  }, [generateInsight]);

  // Generate specific KPI insights
  const generateConversionAnalysis = useCallback(async () => {
    return generateInsight('cvr_analysis', true);
  }, [generateInsight]);

  const generateImpressionTrends = useCallback(async () => {
    return generateInsight('impression_trends', true);
  }, [generateInsight]);

  const generateTrafficSourceAnalysis = useCallback(async () => {
    return generateInsight('traffic_source_performance', true);
  }, [generateInsight]);

  const generateKeywordOptimization = useCallback(async () => {
    return generateInsight('keyword_optimization', true);
  }, [generateInsight]);

  const generateSeasonalAnalysis = useCallback(async () => {
    return generateInsight('seasonal_pattern', true);
  }, [generateInsight]);

  // Helper to check if specific insight type exists
  const hasInsightType = useCallback((type: string) => {
    return existingInsights.some(insight => insight.type === type);
  }, [existingInsights]);

  // Get high priority insights
  const highPriorityInsights = existingInsights.filter(
    insight => insight.priority === 'high'
  );

  // Get user requested insights
  const userRequestedInsights = existingInsights.filter(
    insight => insight.is_user_requested
  );

  // Normalize outputs based on flags without altering hook order
  const gatedEmpty = !isEnabled || shouldReturnEmpty;

  return {
    // Data
    insights: gatedEmpty ? [] : existingInsights,
    highPriorityInsights: gatedEmpty ? [] : highPriorityInsights,
    userRequestedInsights: gatedEmpty ? [] : userRequestedInsights,

    // State
    isLoading: gatedEmpty ? false : isLoading,
    isGenerating: gatedEmpty ? false : isGenerating,
    error: gatedEmpty ? null : error,

    // Actions
    generateConversionAnalysis: gatedEmpty ? (async () => []) : generateConversionAnalysis,
    generateImpressionTrends: gatedEmpty ? (async () => []) : generateImpressionTrends,
    generateTrafficSourceAnalysis: gatedEmpty ? (async () => []) : generateTrafficSourceAnalysis,
    generateKeywordOptimization: gatedEmpty ? (async () => []) : generateKeywordOptimization,
    generateSeasonalAnalysis: gatedEmpty ? (async () => []) : generateSeasonalAnalysis,
    generateComprehensiveInsights: gatedEmpty ? (async () => []) : generateComprehensiveInsights,
    refetchInsights: gatedEmpty ? (async () => {}) : refetch,

    // Utilities
    hasInsightType: gatedEmpty ? (() => false) : hasInsightType
  };
};
