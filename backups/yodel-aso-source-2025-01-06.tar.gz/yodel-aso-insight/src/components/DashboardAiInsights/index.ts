// Dashboard AI Insights Components
export { DashboardAiInsights } from './DashboardAiInsights';
export { AiInsightCard } from './AiInsightCard';
export { generateDemoInsights } from './DemoInsightsGenerator';
export * from './insightCategories';