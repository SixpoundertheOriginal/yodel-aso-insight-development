import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Palette, Search, Image, Loader2, AlertCircle, Brain } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CreativeAnalysisService, type AppInfo, type CreativeAnalysisResult, type CreativeAnalysisWithAI } from '@/services/creative-analysis.service';
import { AppComparisonCard } from './AppComparisonCard';
import { CreativeAnalysisResults } from './CreativeAnalysisResults';
import { cid } from '@/lib/caDebug';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { COUNTRIES } from '@/components/AsoAiHub/MetadataCopilot/PreLaunchForm';
import { AppSelectionModal } from '@/components/shared/AsoShared/AppSelectionModal';
import { ScrapedMetadata } from '@/types/aso';
import { CompetitorCard } from './CompetitorCard';

export const CreativeAnalysisHub: React.FC = () => {
  const [keyword, setKeyword] = useState('fitness');
  const [results, setResults] = useState<CreativeAnalysisResult | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<CreativeAnalysisWithAI | null>(null);
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [searchType, setSearchType] = useState<'keyword' | 'appid'>('keyword');
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [debugMode, setDebugMode] = useState(false);
  const [searchSessionId, setSearchSessionId] = useState<string | null>(null);
  const [selectedCountry, setSelectedCountry] = useState('US');
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedApps, setSelectedApps] = useState<AppInfo[]>([]);
  const [selectedCompetitors, setSelectedCompetitors] = useState<ScrapedMetadata[]>([]);
  const [showCompetitorModal, setShowCompetitorModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'keyword' | 'competitor'>('keyword');

  useEffect(() => {
    const stored = typeof window !== 'undefined' ? localStorage.getItem('ca_selected_country') : null;
    if (stored) {
      setSelectedCountry(stored);
    }
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('ca_selected_country', selectedCountry);
    }
  }, [selectedCountry]);

  const handleSearch = async () => {
    if (!keyword.trim()) return;

    setLoading(true);
    setAiAnalysis(null);
    setCurrentSessionId(null);

    const sessionId = cid();
    setSearchSessionId(sessionId);
    
    try {
      const baseOptions = { debug: debugMode, country: selectedCountry, sessionId };
      const result = searchType === 'keyword'
        ? await CreativeAnalysisService.analyzeCreativesByKeyword(keyword, { ...baseOptions, limit: selectionMode ? 10 : 3 })
        : await CreativeAnalysisService.analyzeCreativesByAppId(keyword, baseOptions);

      setResults(result);
      
      // Create a new session if search was successful
      if (result.success && result.apps.length > 0) {
        try {
          const sessionId = await CreativeAnalysisService.createAnalysisSession(
            keyword.trim(),
            searchType,
            result.apps.length
          );
          setCurrentSessionId(sessionId);
        } catch (sessionError) {
          console.error('Failed to create session:', sessionError);
          // Don't fail the search if session creation fails
        }
      }
    } catch (error) {
      console.error('Search error:', error);
      setResults({
        success: false,
        apps: [],
        totalResults: 0,
        keyword: keyword.trim(),
        country: selectedCountry,
        error: 'Failed to analyze creatives'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleAnalyzeWithAI = async (app?: AppInfo) => {
    if (!results?.apps) return;
    
    setAiLoading(true);
    setAiAnalysis(null);
    setAiError(null);
    
    try {
      const appsToAnalyze = app ? [app] : results.apps;
      const analysis = await CreativeAnalysisService.analyzeCreativesWithAI(
        appsToAnalyze, 
        keyword, 
        currentSessionId || undefined
      );
      setAiAnalysis(analysis);
    } catch (error) {
      console.error('AI analysis failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to analyze screenshots with AI';
      setAiError(errorMessage);
    } finally {
      setAiLoading(false);
    }
  };

  const handleRetryAnalysis = () => {
    if (results?.apps) {
      handleAnalyzeWithAI();
    }
  };

  const toggleSelectionMode = () => {
    setSelectionMode(!selectionMode);
    if (selectionMode) {
      setSelectedApps([]);
    }
  };

  const handleAppSelection = (app: AppInfo, selected: boolean) => {
    setSelectedApps(prev => {
      if (selected) {
        if (prev.find(a => a.appId === app.appId) || prev.length >= 5) {
          return prev;
        }
        return [...prev, app];
      }
      return prev.filter(a => a.appId !== app.appId);
    });
  };

  const clearAllSelections = () => {
    setSelectedApps([]);
  };

  const handleAnalyzeSelected = async () => {
    if (selectedApps.length < 2) {
      setAiError('Please select at least 2 apps');
      return;
    }
    try {
      setAiLoading(true);
      const analysis = await CreativeAnalysisService.analyzeCreativesWithAI(selectedApps);
      setAiAnalysis(analysis);
    } catch (error) {
      setAiError(error instanceof Error ? error.message : 'Failed to analyze selected apps');
    } finally {
      setAiLoading(false);
    }
  };

  const handleChooseCompetitors = () => {
    setShowCompetitorModal(true);
  };

  const handleCompetitorSelection = (competitors: ScrapedMetadata[]) => {
    setSelectedCompetitors(competitors);
    setShowCompetitorModal(false);
    if (competitors.length > 0) {
      setActiveTab('competitor');
    }
  };

  const convertToAppInfo = (metadata: ScrapedMetadata[]): AppInfo[] => {
    return metadata.map(app => ({
      appId: String(app.bundleId || app.appId || app.trackId || ''),
      title: String(app.name || app.title || ''),
      screenshots: app.screenshots || (app.screenshot ? [app.screenshot] : []),
      icon: String(app.icon || ''),
      rating: Number(app.rating || 0),
      developer: String(app.developer || ''),
      country: selectedCountry
    }));
  };

  const handleAnalyzeCompetitors = async () => {
    const competitorAppInfo = convertToAppInfo(selectedCompetitors);
    try {
      setAiLoading(true);
      const analysis = await CreativeAnalysisService.analyzeCreativesWithAI(competitorAppInfo);
      setAiAnalysis(analysis);
    } catch (error: any) {
      setAiError(error.message);
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-foreground">
      <div className="container mx-auto px-6 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-pink-600 shadow-lg">
              <Palette className="h-6 w-6 text-foreground" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Creative Analysis</h1>
              <p className="text-zinc-400">Analyze app store creatives and visual strategies</p>
            </div>
          </div>
        </div>

        <div className="analysis-tabs flex gap-2 mb-6">
          <Button
            variant={activeTab === 'keyword' ? 'default' : 'outline'}
            onClick={() => setActiveTab('keyword')}
          >
            Keyword Analysis
          </Button>
          <Button
            variant={activeTab === 'competitor' ? 'default' : 'outline'}
            onClick={() => setActiveTab('competitor')}
          >
            Competitor Analysis ({selectedCompetitors.length})
          </Button>
        </div>

        {activeTab === 'keyword' && (
          <>
        {/* Search Interface */}
        <Card className="bg-zinc-900 border-zinc-800 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Search className="h-5 w-5" />
              Creative Search
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <Button
                variant={searchType === 'keyword' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSearchType('keyword')}
                className="text-xs"
              >
                Keyword Search
              </Button>
              <Button
                variant={searchType === 'appid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSearchType('appid')}
                className="text-xs"
              >
                App ID Lookup
              </Button>
              {process.env.NODE_ENV === 'development' && (
                <Button
                  onClick={() => setDebugMode(!debugMode)}
                  variant="outline"
                  size="sm"
                >
                  🔍 Debug: {debugMode ? 'ON' : 'OFF'}
                </Button>
              )}
              <Button
                variant={selectionMode ? 'default' : 'outline'}
                onClick={toggleSelectionMode}
                size="sm"
                className="text-xs"
              >
                {selectionMode ? 'Manual Selection' : 'Auto Analysis'}
              </Button>
              {selectionMode && (
                <div className="flex items-center gap-2 text-xs text-zinc-400">
                  <span>{selectedApps.length} apps selected</span>
                  {selectedApps.length > 0 && (
                    <Button variant="ghost" size="sm" onClick={clearAllSelections}>
                      Clear All
                    </Button>
                  )}
                </div>
              )}
              <Button onClick={handleChooseCompetitors} variant="outline" size="sm" className="text-xs">
                Choose Competitors
              </Button>
              <div className="ml-auto flex items-center gap-2">
                <Label className="text-xs text-zinc-400">App Store Region</Label>
                <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                  <SelectTrigger className="w-40 bg-zinc-800 border-zinc-700 text-foreground">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-800 border-zinc-700">
                    {COUNTRIES.map((country) => (
                      <SelectItem key={country.code} value={country.code} className="text-foreground">
                        {country.flag} {country.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex gap-3">
              <Input
                type="text"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                onKeyPress={handleKeyPress}
                className="flex-1 bg-zinc-800 border-zinc-700 text-foreground placeholder-zinc-400"
                placeholder={searchType === 'keyword' ? 'Enter keyword (e.g., fitness, gaming)' : 'Enter App Store ID'}
              />
              <Button
                onClick={handleSearch}
                disabled={loading || !keyword.trim()}
                className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-foreground border-0"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Analyze
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Error Display */}
        {results?.error && (
          <Alert className="mb-8 bg-red-950 border-red-800">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-red-200">
              {results.error}
            </AlertDescription>
          </Alert>
        )}

        {/* Results Display */}
        {results?.success && (
          <div className="space-y-8">
            {/* Results Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <h2 className="text-2xl font-bold text-foreground">Analysis Results</h2>
                <Badge variant="secondary" className="bg-zinc-800 text-zinc-200">
                  {results.totalResults} {results.totalResults === 1 ? 'app' : 'apps'} found
                </Badge>
              </div>
              <div className="text-sm text-zinc-400 flex flex-col items-end sm:flex-row sm:items-center sm:gap-2">
                <span>Search: "{results.keyword}"</span>
                <span>
                  {COUNTRIES.find(c => c.code === results.country)?.flag}
                  {" "}
                  {COUNTRIES.find(c => c.code === results.country)?.name} App Store
                </span>
              </div>
            </div>

            {/* App Results */}
            {results.apps.length > 0 ? (
              <div className="space-y-8">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-semibold text-zinc-100">
              Analysis Results
            </h3>
            {selectionMode ? (
              <Button
                onClick={handleAnalyzeSelected}
                disabled={selectedApps.length < 2 || aiLoading}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                {aiLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>Analyze {selectedApps.length} Selected Apps</>
                )}
              </Button>
            ) : (
              results.apps.some(app => app.screenshots.length > 0) && (
                <Button
                  onClick={() => handleAnalyzeWithAI()}
                  disabled={aiLoading}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  {aiLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing All...
                    </>
                  ) : (
                    <>
                      <Brain className="w-4 h-4 mr-2" />
                      Analyze All with AI
                    </>
                  )}
                </Button>
              )
            )}
          </div>

          {results.apps.map((app, index) => (
            <AppComparisonCard
              key={app.appId}
              app={app}
              rank={index + 1}
              onAnalyzeWithAI={handleAnalyzeWithAI}
              isAnalyzing={aiLoading}
              sessionId={searchSessionId || undefined}
              selectionMode={selectionMode}
              isSelected={selectedApps.some(a => a.appId === app.appId)}
              onSelectionChange={handleAppSelection}
            />
          ))}

          {/* AI Analysis Error */}
          {aiError && (
            <Card className="border-red-800 bg-red-900/20 mt-8">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-red-400 mb-2">AI Analysis Failed</h3>
                    <p className="text-red-300">{aiError}</p>
                  </div>
                  <Button 
                    onClick={handleRetryAnalysis}
                    variant="outline"
                    className="border-red-600 text-red-400 hover:bg-red-900/30"
                  >
                    Retry Analysis
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* AI Analysis Results */}
          {aiAnalysis && (
            <div className="mt-8">
              <CreativeAnalysisResults
                analysis={aiAnalysis}
                keyword={keyword}
                apps={results.apps}
              />
            </div>
          )}
              </div>
            ) : (
              <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="py-12 text-center">
                  <Image className="h-12 w-12 mx-auto mb-4 text-zinc-500" />
                  <p className="text-zinc-400">No apps found for the search term.</p>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Empty State */}
        {!results && !loading && (
          <Card className="bg-zinc-900 border-zinc-800">
            <CardContent className="py-12 text-center">
              <Palette className="h-16 w-16 mx-auto mb-6 text-zinc-500" />
              <h3 className="text-xl font-semibold text-foreground mb-2">Ready to Analyze Creatives</h3>
              <p className="text-zinc-400 mb-6">
                Enter a keyword or App Store ID to start analyzing app store creatives and visual strategies.
              </p>
              <div className="max-w-md mx-auto space-y-2 text-sm text-zinc-500">
                <p>• Analyze top-ranking apps' visual designs</p>
                <p>• Compare screenshot strategies</p>
                <p>• Identify creative trends and patterns</p>
              </div>
            </CardContent>
          </Card>
        )}
          </>
        )}

        {activeTab === 'competitor' && (
          <div className="competitor-analysis-section space-y-6">
            <div className="competitor-collection space-y-4">
              <h3 className="text-xl font-semibold text-foreground">Selected Competitors ({selectedCompetitors.length}/5)</h3>
              <div className="competitor-cards grid gap-4">
                {selectedCompetitors.map((competitor) => (
                  <CompetitorCard
                    key={String(competitor.bundleId || competitor.appId || competitor.trackId || `competitor-${Date.now()}`)}
                    app={competitor}
                    onRemove={(app) =>
                      setSelectedCompetitors((prev) => prev.filter((c) => c.bundleId !== app.bundleId))
                    }
                  />
                ))}
              </div>
              <div className="flex gap-2">
                <Button onClick={handleChooseCompetitors} variant="outline">
                  Choose Competitors
                </Button>
                {selectedCompetitors.length > 0 && (
                  <Button onClick={handleAnalyzeCompetitors} disabled={aiLoading} className="analyze-competitors-button">
                    {aiLoading ? 'Analyzing...' : `Analyze ${selectedCompetitors.length} Competitors`}
                  </Button>
                )}
              </div>
            </div>

            {aiAnalysis && (
              <div className="competitor-analysis-results">
                <CreativeAnalysisResults
                  analysis={aiAnalysis}
                  keyword={keyword}
                  apps={convertToAppInfo(selectedCompetitors)}
                />
              </div>
            )}
          </div>
        )}
      </div>
      <AppSelectionModal
        isOpen={showCompetitorModal}
        onClose={() => setShowCompetitorModal(false)}
        candidates={[]}
        onSelect={() => {}}
        searchTerm={keyword}
        selectMode="multi"
        onMultiSelect={handleCompetitorSelection}
        maxSelections={5}
        selectedApps={selectedCompetitors}
        searchCountry={selectedCountry}
      />
    </div>
  );
};